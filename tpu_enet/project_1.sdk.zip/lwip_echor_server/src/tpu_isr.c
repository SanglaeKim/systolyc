/*
 * tpu_isr.c
 *
 *  Created on: 2025. 1. 13.
 *      Author: User
 */
#include "tpu_enet.h"
#include "tpu_isr.h"
#include "globals.h"

void isr_even_pl2ps(void *CallbackRef) {
  if (!bPL2PS_READ_EVENT) {
	isr_cnt_even++;
	bPL2PS_READ_EVENT = true;
	rd_event_type = PL2PS_EVENT_EVEN;
  }
}

void isr_odd_pl2ps(void *CallbackRef) {
  if (!bPL2PS_READ_EVENT) {
	isr_cnt_odd++;
	bPL2PS_READ_EVENT = true;
	rd_event_type = PL2PS_EVENT_ODD;
  }
}

void isr_cdma(void *CallBackRef, u32 IrqMask, int *IgnorePtr) {
  bPL2PS_READ_EVENT = false;
  isr_cnt_cdma++;
  if (IrqMask & XAXICDMA_XR_IRQ_ERROR_MASK) {Error = TRUE;}
  if (IrqMask & XAXICDMA_XR_IRQ_IOC_MASK  ) {Done  = TRUE;}
}

void isr_cdma_ps2pl(void *CallBackRef, u32 IrqMask, int *IgnorePtr) {
  bPS2PL_EVENT = false;
  isr_cnt_cdma_ps2pl++;
  if (IrqMask & XAXICDMA_XR_IRQ_ERROR_MASK) {Error_ps2pl = TRUE;}
  if (IrqMask & XAXICDMA_XR_IRQ_IOC_MASK  ) {Done_ps2pl  = TRUE;}
}

//=================================================================
//	SCU GIC (global interrupt) �ʱ�ȭ
//=================================================================
int GIC_Init(XScuGic *pXScuGic) {
  int Status;
  XScuGic_Config *IntcConfig;


  XScuGic_DeviceInitialize(INTC_DEVICE_ID);

  IntcConfig = XScuGic_LookupConfig(XPAR_SCUGIC_SINGLE_DEVICE_ID);
  if (NULL == IntcConfig) {	return XST_FAILURE;  }

  Status = XScuGic_CfgInitialize(pXScuGic, IntcConfig, IntcConfig->CpuBaseAddress);
  if (Status != XST_SUCCESS) {	return XST_FAILURE;  }

///////////////////////////////////////////////////////////
  Xil_ExceptionRegisterHandler(
		  	    XIL_EXCEPTION_ID_IRQ_INT
			  ,(Xil_ExceptionHandler) XScuGic_InterruptHandler
			  , pXScuGic);
////////////////////////////////////////////////////////////////
  Xil_ExceptionInit();

  Xil_ExceptionEnable();

  return XST_SUCCESS;
}


//=================================================================
//	Interrupt ����
//=================================================================

int Enable_IntrruptSystem(XScuGic *pXScuGicInst, u16 IntrruptId,  Xil_ExceptionHandler InterruptHandler) {
  int Status = 0;

  //	DP_RAM ���ͷ�Ʈ Ʈ���� ����
  if (IntrruptId == INTERRUPT_ID_PL2PS_EVEN || IntrruptId == INTERRUPT_ID_PL2PS_ODD) {
	XScuGic_SetPriorityTriggerType(pXScuGicInst, IntrruptId, 0x00, 0x3);
  }

  Status = XScuGic_Connect(pXScuGicInst
		  	  	  	  	  , IntrruptId
						  , (Xil_ExceptionHandler) InterruptHandler
						  , (void *) pXScuGicInst);

  if (Status != XST_SUCCESS) {
	return Status;
  }

  XScuGic_Enable(pXScuGicInst, IntrruptId);

  return Status;
}

void setupInterrupt(XScuGic *pXScuGic) {
  int Status;
  //	GIC ���� �� �ʱ�ȭ
  GIC_Init(pXScuGic);

  //	���ͷ�Ʈ ����
  //	PL to PS DP_RAM Even Interrupt ��� (GIC�� ���ͷ�Ʈ ����) - PL(FPGA)���� ������ �о���� ���� ���ͷ�Ʈ
  Enable_IntrruptSystem(pXScuGic, INTERRUPT_ID_PL2PS_EVEN,	isr_even_pl2ps);

  //	PL to PS DP_RAM Odd Interrupt ���  (GIC�� ���ͷ�Ʈ ����) - PL(FPGA)���� ������ �о���� ���� ���ͷ�Ʈ
  Enable_IntrruptSystem(pXScuGic, INTERRUPT_ID_PL2PS_ODD,	isr_odd_pl2ps);

//  Enable_IntrruptSystem(&pXScuGic, XPAR_XTTCPS_0_INTR,	(Xil_ExceptionHandler)timer_callback);
//  Enable_IntrruptSystem(&pXScuGic, XPAR_XTTCPS_0_INTR,	timer_callback);

  //	DMA ����̽� �ʱ�ȭ
  //	PL to PS DMA
  Status = Init_CDMA(pXScuGic, &instCDMA_PLtoPS, DEVICE_ID_CDMA0, INTERRUPT_ID_CDMA0);
  if (Status == XST_FAILURE) xil_printf("Init_CDMA Failed!!\r\n");

  Status = Init_CDMA(pXScuGic, &instCDMA_PStoPL, DEVICE_ID_CDMA1, INTERRUPT_ID_CDMA1);
  if (Status == XST_FAILURE) xil_printf("Init_CDMA Failed!!\r\n");

}


//================================================================================
//	CDMA ���� �� ���ͷ�Ʈ ���
//================================================================================
int Init_CDMA(XScuGic *pXScuGicInst, XAxiCdma *pXAxiCdmaInst, u16 DeviceId,  u32 IntrId)
{
  XAxiCdma_Config *CfgPtr;
  int Status;

  // Initialize the XAxiCdma device.
  CfgPtr = XAxiCdma_LookupConfig(DeviceId);
  if (!CfgPtr) {
	return XST_FAILURE;
  }

  Status = XAxiCdma_CfgInitialize(pXAxiCdmaInst, CfgPtr, CfgPtr->BaseAddress);
  if (Status != XST_SUCCESS) {
	return XST_FAILURE;
  }

  //	CDMA�� GIC�� ���� (CDMA ���ͷ�Ʈ ���)
  Enable_CMDA_Intrrupt(pXScuGicInst, pXAxiCdmaInst, IntrId);

  // Enable all (completion/error/delay) interrupts
  XAxiCdma_IntrEnable(pXAxiCdmaInst, XAXICDMA_XR_IRQ_ALL_MASK);

  return XST_SUCCESS;
}

int Enable_CMDA_Intrrupt(XScuGic *pXScuGicInst, XAxiCdma *pXAxiCdmaInst, u32 IntrId)
{
  int Status;

  XScuGic_SetPriorityTriggerType(pXScuGicInst, IntrId, 0xA0, 0x3);

  // Connect the device driver handler that will be called when an
  // interrupt for the device occurs, the handler defined above performs
  // the specific interrupt processing for the device.

  Status = XScuGic_Connect(pXScuGicInst
		  	  	  	  , IntrId
					  , (Xil_InterruptHandler) XAxiCdma_IntrHandler
					  , pXAxiCdmaInst);

  if (Status != XST_SUCCESS) {
	return Status;
  }

  //Enable the interrupt for the DMA device.
  XScuGic_Enable(pXScuGicInst, IntrId);

  return XST_SUCCESS;
}




